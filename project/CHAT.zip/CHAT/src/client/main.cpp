#include "json.hpp"
#include <iostream>
#include <thread>
#include <string>
#include <vector>
#include <chrono>
#include <ctime>
using namespace std;
using json = nlohmann::json;

#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "group.hpp"
#include "user.hpp"
#include "public.hpp"

//记录当前登陆的用户信息
User g_currentUser;
//记录当前登陆的好友列表信息---当登陆成功时服务器会返回这些信息，把他们记录下来，以后再看就不需要向服务器请求了
vector<User> g_currentUserFriendList;
//记录当前登陆用户的群组列表信息
vector<Group> g_currentUserGroupList;
//显示当前登陆成功用户的基本信息
void showCurrentUserData();

//接受线程
void readTaskHandler(int clientfd);
//获取系统时间（聊天时需要添加时间信息）
string getCurrentTime();
//主聊天页面程序
void mainMenu(int);

//聊天客户端实现，main线程用作发送线程，子线程用于接受线程
int main(int argc, const char **argv)
{
    //启动chatclient时需要传入chatserver的ip地址和端口号port
    if (argc < 3)
    {
        cerr << "command invalid！ example: ./ChatClient 127.0.0.1 6000" << endl;
    }
    //解析命令行参数传递的ip和port
    const char *ip = argv[1];
    uint16_t port = atoi(argv[2]); //unsigned_short

    //创建client端的socket
    int clientfd = socket(AF_INET, SOCK_STREAM, 0);
    if (clientfd == -1)
    {
        cerr << "socket create error" << endl;
        exit(-1);
    }

    //填写client需要连接server信息 ：ip+port
    sockaddr_in server;
    memset(&server, 0, sizeof(sockaddr_in));

    server.sin_family = AF_INET;
    server.sin_port = htons(port);
    server.sin_addr.s_addr = inet_addr(ip); //inet_addr()实现点分十进制ip地址到32位ip地址转换

    //client和server进行连接
    if (connect(clientfd, (sockaddr *)&server, sizeof(sockaddr_in)) == -1)
    {
        cerr << "connect server error" << endl;
        close(clientfd);
        exit(-1);
    }

    //main线程用于接受用户输入，负责发送数据
    for (;;)
    {
        //显示首页面菜单 登陆 注册 退出
        cout << "===========================" << endl;
        cout << "1. login" << endl;
        cout << "2. register" << endl;
        cout << "3. quit" << endl;
        cout << "===========================" << endl;
        cout << "choice:";
        int choice = 0;
        cin >> choice;
        cin.get(); //读取缓冲区残留的回车
        /*
            STDIN_FILENO:
            　　1).数据类型：int
            　　2).层次：系统级的API，是一个文件句柄，定义在<unistd.h>中。
            　　3).相应的函数：open()，close()，read()，write()，lseek()等系统级别的函数。
            stdin：
            　　1).数据类型：FILE *
            　　2).层次：c语言的提供的标准输入流。c语言标准库封装系统函数实现。高级的输入输出函数。可在<stdio.h>中找到外部声明。
            　　3).相应的函数：fopen()，fclose()，fread()，fwrite()，fseek()等c语言标准函数。
            STDIN_FILENO是调用系统api时获取和传递的参数，stdin是调用c语言库api时获取和传递的参数
            stdin是一个FILE*结构体，里面包含了STDIN_FILENO这个fd，两个东西本质都一样的，用系统api就用STDIN_FILENO作为参数，用c库api就用stdin作为参数
            stdin结构体中还封装了用户缓冲区buf
            cin,cout,printf等系统调用会有自己的用户缓冲区buf，先将数据写入buf，然后调用底层系统api--write或者read，
            将buf数据传入标准输入输出fd对应的内和缓冲区中，然后操作系统将数据发送给显卡，显卡进行显示。

            其中cin会读到回车字符就停止，不会将回车读出来，故接上cin.get()将本句回车也读了，防止回车留在缓冲区，后续读取字符串时将回车当作一个完整的字符串读出来
        */
        switch (choice)
        {
        case 1: //登陆业务
        {
            int id = 0;
            char pwd[50] = {0};
            cout << "userid:";
            cin >> id;
            cin.get(); //读掉缓冲区残留的回车
            cout << "userpassword:";
            cin.getline(pwd, 50);

            json js;
            js["msgid"] = LOGIN_MSG;
            js["id"] = id;
            js["password"] = pwd;
            string request = js.dump();

            int len = send(clientfd, request.c_str(), strlen(request.c_str()) + 1, 0);
            if (len == -1)
            {
                cerr << "send login msg error:" << request << endl;
            }
            else
            {
                char buffer[1024] = {0};
                len = recv(clientfd, buffer, 1024, 0);
                if (len == -1)
                {
                    cerr << "recv login response error" << endl;
                }
                else
                {
                    json responsejs = json::parse(buffer);
                    if (responsejs["errno"].get<int>() != 0)
                    { //登陆失败
                        cerr << responsejs["errmsg"] << endl;
                    }
                    else
                    { //登陆成功
                        //记录当前用户的id和name
                        g_currentUser.setId(responsejs["id"].get<int>());
                        g_currentUser.setName(responsejs["name"]);

                        //记录当前用户的好友列表信息
                        if (responsejs.contains("friends"))
                        {
                            vector<string> vec = responsejs["friends"];
                            for (string &str : vec)
                            {
                                json js = json::parse(str);
                                User user;
                                user.setId(js["id"].get<int>());
                                user.setName(js["name"]);
                                user.setState(js["state"]);
                                g_currentUserFriendList.push_back(user);
                            }
                        }

                        //记录当前用户的群组信息
                        if (responsejs.contains("groups"))
                        {
                            vector<string> vec1 = responsejs["groups"];
                            for (string &groupstr : vec1)
                            {
                                json grpjs = json::parse(groupstr);
                                Group group;
                                group.setId(grpjs["id"].get<int>());
                                group.setName(grpjs["groupname"]);
                                group.setDesc(grpjs["groupdesc"]);

                                vector<string> vec2 = grpjs["users"];
                                for (string &userstr : vec2)
                                {
                                    GroupUser user;
                                    json js = json::parse(userstr);
                                    user.setId(js["id"].get<int>());
                                    user.setName(js["name"]);
                                    user.setState(js["state"]);
                                    user.setRole(js["role"]);
                                    group.getUsers().push_back(user);
                                }
                                g_currentUserGroupList.push_back(group);
                            }
                        }

                        //显示登陆用户的基本信息
                        showCurrentUserData();

                        //显示当前用户的离线消息：个人聊天消息或者群组消息
                        //离线消息的json格式时客户端发送聊天消息时确定的，服务器接受后如果用户离线就将json转为字符串存入offlinemsg表中
                        //当用户登陆后将字符串原封不动返回给用户客户端
                        if (responsejs.contains("offlinemsg"))
                        {
                            vector<string> vec = responsejs["offlinemsg"];
                            for (string &str : vec)
                            {
                                json js = json::parse(str);
                                //time +[id]+name+"said:"+xxx
                                int msgtype = js["msgid"].get<int>();
                                if (ONE_CHAT_MSG == msgtype)
                                {
                                    cout << js["time"].get<string>() << " [" << js["id"] << "]" << js["name"].get<string>() << "said:" << js["msg"].get<string>() << endl;
                        
                                }
                                else if (GROUP_CHAT_MSG == msgtype)
                                {
                                    cout << "群消息[" << js["groupid"] << "]:" << js["time"].get<string>() << " [" << js["id"] << "]" << js["name"].get<string>() << "said:" << js["msg"].get<string>() << endl;
                           
                                }
                                
                            }
                        }

                        //登陆成功 启动接受线程负责接受数据
                        std::thread readTask(readTaskHandler, clientfd);
                        readTask.detach();

                        //进入聊天主菜单页面
                        mainMenu(clientfd);
                    }
                }
            }
        }
        break;
        case 2: //register业务
        {
            char name[50] = {0};
            char pwd[50] = {0};
            cout << "username:";
            cin.getline(name, 50);   //cin>>和scanf在读取字符串时，遇到空格回车或者非法字符都直接结束读取，用这些没法输入带空格的字符串(姓名.密码)
            cout << "userpassword:"; //cin.getline()默认遇到回车才结束
            cin.getline(pwd, 50);

            json js;
            js["msgid"] = REG_MSG;
            js["name"] = name;
            js["password"] = pwd;
            string request = js.dump();

            //将组织好的json对象发送出去
            int len = send(clientfd, request.c_str(), strlen(request.c_str()) + 1, 0);
            if (len == -1)
            {
                cerr << "recv reg response error" << endl;
            }
            else
            {
                char buffer[1024] = {0};
                len = recv(clientfd, buffer, 1024, 0);
                if (len == -1)
                {
                    cerr << "recv reg response errno" << endl;
                }
                else
                {
                    //json字符串的反序列化
                    json responsejs = json::parse(buffer);
                    if (responsejs["errno"].get<int>() != 0)
                    { //注册失败
                        cerr << name << "is already exist,register error!" << endl;
                    }
                    else
                    { //注册成功
                        cout << name << "register success,userid is " << responsejs["id"] << ",do not forget it!" << endl;
                    }
                }
            }
        }
        break;
        case 3: //quit业务
        {
            close(clientfd);
            exit(0);
        }
        default:
            cerr << "invalid input!" << endl;
            break;
        }
    }
}

void showCurrentUserData()
{
    cout << "=======================login user======================" << endl;
    cout << "current login user => id:" << g_currentUser.getId() << "  name:" << g_currentUser.getName() << endl;
    cout << "-----------------------friend list----------------------" << endl;
    if (!g_currentUserFriendList.empty())
    {
        for (User &user : g_currentUserFriendList)
        {
            cout << user.getId() << " " << user.getName() << " " << user.getState() << endl;
        }
    }
    cout << "-----------------------group list----------------------" << endl;
    if (!g_currentUserGroupList.empty())
    {
        for (Group &group : g_currentUserGroupList)
        {
            cout << group.getId() << " " << group.getName() << " " << group.getDesc() << endl;
            for (GroupUser &user : group.getUsers())
            {
                cout << user.getId() << " " << user.getName() << " " << user.getState() << " " << user.getRole() << endl;
            }
        }
    }
    cout << "=======================================================" << endl;
}

//接收线程
void readTaskHandler(int clientfd)
{
    for (;;)
    {
        char buffer[1024] = {0};
        int len = recv(clientfd, buffer, 1024, 0);
        if (len == -1 || len == 0)
        {
            close(clientfd);
            exit(-1);
        }

        //接受ChatServer转发的数据，反序列化生成json数据对象
        json js = json::parse(buffer);
        int msgtype = js["msgid"].get<int>();
        if (ONE_CHAT_MSG == msgtype)
        {
            cout << js["time"].get<string>() << " [" << js["id"] << "]" << js["name"].get<string>() << " said:" << js["msg"].get<string>() << endl;
            continue;
        }
        else if (GROUP_CHAT_MSG == msgtype)
        {
            cout << "群消息[" << js["groupid"] << "]:" << js["time"].get<string>() << " [" << js["id"] << "]" << js["name"].get<string>() << " said:" << js["msg"].get<string>() << endl;
            continue;
        }
    }
}
string getCurrentTime()
{
    /*
        chrono是一个time library
        now() 当前时间time_point
        to_time_t() time_point转换成time_t秒(转成一个unix时间戳)
        localtime将time_t转换为本地时间(local time),主要做的就是将大整数值time_t转换成易读取的时间
    */
    auto tt=std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
    struct tm*ptm=localtime(&tt);
    char date[60]={0};
    sprintf(date,"%d-%02d-%02d %02d:%02d:%02d",(int)ptm->tm_year+1900,(int)ptm->tm_mon+1,(int)ptm->tm_mday,
    (int)ptm->tm_hour,(int)ptm->tm_min,(int)ptm->tm_sec);
    return std::string(date);
    
    
}

//help--conmmand handler
void help(int fd = 0, string str = "");
//chat--conmmand handler
void chat(int, string);
//addfriend--conmmand handler
void addfriend(int, string);
//creategroup--conmmand handler
void creategroup(int, string);
//addgroup--conmmand handler
void addgroup(int, string);
//groupchat--conmmand handler
void groupchat(int, string);
//loginout--conmmand handler
void loginout(int, string);

//系统支持的客户端命令列表
unordered_map<string, string> commandMap = {
    {"help", "显示所有支持的命令，格式help"},
    {"chat", "一对一了天，格式chat:friendid:message"},
    {"addfriend", "添加好友，格式addfriend:friendid"},
    {"creategroup", "创建群组，格式creategroup:groupname:groupdesc"},
    {"addgroup", "加入群组，格式addgroup:groupid"},
    {"groupchat", "群聊，格式groupchat:groupid:message"},
    {"loginout", "注销，格式loginout"},
};

//注册系统支持的客户端命令处理 int--clientfd string--数据
unordered_map<string, function<void(int, string)>> commandHandlerMap = {
    {"help", help},
    {"chat", chat},
    {"addfriend", addfriend},
    {"creategroup", creategroup},
    {"addgroup", addgroup},
    {"groupchat", groupchat},
    {"loginout", loginout}};

//主聊天页面程序
void mainMenu(int clientfd)
{

    //显示系统所支持的命令
    help();
    char buffer[1024] = {0};
    for (;;)
    {
        cin.getline(buffer, 1024); //cin.getline()默认遇到回车才结束，可以读取空格
        string commandbuf(buffer);
        string command; //存储命令
        int idx = commandbuf.find(":");
        if (idx == -1)
        {
            command = commandbuf; //因为loginout和help找不到":"
        }
        else
        {
            command = commandbuf.substr(0, idx);
        }
        auto it = commandHandlerMap.find(command);
        if (it == commandHandlerMap.end())
        {
            cerr << "invalid input command!" << endl;
            continue;
        }

        //调用相应命令的事件处理回调，mainMenu对修改封闭，对扩展开放,添加新功能不需要修改mainMenu函数
        it->second(clientfd, commandbuf.substr(idx + 1, commandbuf.size() - idx)); //调用命令处理方法
    }
}

//help--conmmand handler
void help(int fd, string str)
{
    cout << "show command list >>>" << endl;
    for (auto &p : commandMap)
    {
        cout << p.first << " : " << p.second << endl;
    }
    cout << endl;
}

/*json格式 
          msgid ONE_CHAT_MSG
          id:1
          name:"zhangsan"
          to:3
          msg:"xxx"
*/
//chat--conmmand handler
void chat(int clientfd, string str)
{
    int idx = str.find(":");
    if (idx == -1)
    {
        cerr << "chat command invalid!" << endl;
        return;
    }
    int friendid = atoi(str.substr(0, idx).c_str());
    string message = str.substr(idx + 1, str.size() - idx-1);

    json js;
    js["msgid"] = ONE_CHAT_MSG;
    js["id"] = g_currentUser.getId();
    js["name"] = g_currentUser.getName();
    js["to"] = friendid;
    js["msg"] = message;
    js["time"] = getCurrentTime();
    string buffer = js.dump();

    int len = send(clientfd, buffer.c_str(), strlen(buffer.c_str()) + 1, 0);
    if (len == -1)
    {
        cerr << "send chat msg error ->" << buffer << endl;
    }
}

/*json格式 
          msgid ADD_FRIEND_MSG
          id:1
          friendid:3
*/
//addfriend--conmmand handler
void addfriend(int clientfd, string str)
{
    int friendid = atoi(str.c_str());
    json js;
    js["msgid"] = ADD_FRIEND_MSG;
    js["id"] = g_currentUser.getId();
    js["friendid"] = friendid;
    string buffer = js.dump();

    int len = send(clientfd, buffer.c_str(), strlen(buffer.c_str()) + 1, 0);
    if (len == -1)
    {
        cerr << "send addfriend msg error -> " << buffer << endl;
    }
}

/*json格式 
          msgid CREATE_GROUP_MSG
          id:1
          groupname:""
          groupdesc:""
*/
//creategroup--conmmand handler
void creategroup(int clientfd, string str)
{
    int idx = str.find(":");
    if (idx == -1)
    {
        cerr << "creategroup command invalid!" << endl;
        return;
    }

    string groupname = str.substr(0, idx);
    string groupdesc = str.substr(idx + 1, str.size() - idx);

    json js;
    js["msgid"] = CREATE_GROUP_MSG;
    js["id"] = g_currentUser.getId();
    js["groupname"] = groupname;
    js["groupdesc"] = groupdesc;
    string buffer = js.dump();

    int len = send(clientfd, buffer.c_str(), strlen(buffer.c_str()) + 1, 0);
    if (len == -1)
    {
        cerr << "send creategroup msg error -> " << buffer << endl;
    }
}

/*json格式 
          msgid ADD_GROUP_MSG
          id:13
          groupid:1
*/
//addgroup--conmmand handler
void addgroup(int clientfd, string str)
{
    int groupid = stoi(str);

    json js;
    js["msgid"] = ADD_GROUP_MSG;
    js["id"] = g_currentUser.getId();
    js["groupid"] = groupid;
    string buffer = js.dump();

    int len = send(clientfd, buffer.c_str(), strlen(buffer.c_str()) + 1, 0);
    if (len == -1)
    {
        cerr << "send addgroup msg error -> " << buffer << endl;
    }
}

/*json格式 
          msgid ADD_GROUP_MSG
          id:13
          groupid:1
          msg:""
*/
//groupchat--conmmand handler
void groupchat(int clientfd, string str)
{
    int idx = str.find(":");
    if (idx == -1)
    {
        cerr << "groupchat command invalid!" << endl;
        return;
    }

    int groupid = stoi(str.substr(0, idx));
    string message = str.substr(idx + 1, str.size() - idx);

    json js;
    js["msgid"] = GROUP_CHAT_MSG;
    js["id"] = g_currentUser.getId();
    js["name"] = g_currentUser.getName();
    js["groupid"] = groupid;
    js["msg"] = message;
    js["time"] = getCurrentTime();
    string buffer = js.dump();

    int len = send(clientfd, buffer.c_str(), strlen(buffer.c_str()) + 1, 0);
    if (len == -1)
    {
        cerr << "send groupchat msg error -> " << buffer << endl;
    }
}
//loginout--conmmand handler
void loginout(int, string)
{
}